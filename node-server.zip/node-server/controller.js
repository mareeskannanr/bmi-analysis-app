let Book = require('./book.model');

exports.getAllBooks = (req, res) => {
    Book.find({}, (err, result) => {
        if(err) {
            //console.error(err);
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }
        res.status(200).json(result);
    });
};

exports.getBookById = (req, res) => {
    Book.findById(req.params.id, (err, result) => {
        if(err) {
            //console.error(err);
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }

        res.status(200).json(result);
    });
};

exports.saveBook = (req, res) => {
    let book = new Book(req.body);

    book.save(err => {
        if(err) {
            //console.error(err);

            if(err.code === 11000) {
                return res.status(422).json({
                    error: 'ISBN already exists for other book.'
                });
            }

            if (err.name === 'ValidationError') {
                //console.error('Error Validating!', err);
                let errorArray = [];
                for(let prop in err.errors) {
                    errorArray.push(err.errors[prop].message);
                }

                return res.status(422).json({
                    errors: errorArray
                });
            }
                
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }

        res.status(201).json({
            message: "Book Information Added Successfully!"
        });
    });
};

exports.updateBook = (req, res) => {
    Book.findByIdAndUpdate(req.params.id, {$set: req.body}, (err, result) => {
        if(err) {
            //console.error(err);

            if(err.code === 11000) {
                return res.status(422).json({
                    error: 'ISBN already exists for other book.'
                });
            }

            if (err.name === 'ValidationError') {
                //console.error('Error Validating!', err);
                let errorArray = [];
                for(let prop in err.errors) {
                    errorArray.push(err.errors[prop].message);
                }

                return res.status(422).json({
                    errors: errorArray
                });
            }
                
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }

        //console.log(result);
        res.status(200).json({
            message: "Book Information Updated Successfully!"
        });
    });
};

exports.deleteBook = (req, res) => {
    Book.findByIdAndDelete(req.params.id, (err, result) => {
        if(err) {
            //console.error(err);
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }

        //console.log(result);
        res.status(204).json({
            message: "Book Information removed Successfully!"
        });
    });
};

exports.deleteAllBooks = (req, res) => {
    Book.remove({}, (err, result) => {
        if(err) {
            //console.error(err);
            return res.status(500).json({
                message: "Sorry Something Went Wrong",
                error: err
            });
        }

        //console.log(result);
        res.status(204).json({
            message: "All Book Information removed Successfully!"
        });
    });
};