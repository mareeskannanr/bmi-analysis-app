let express = require('express');
let app = express();
let logger = require('morgan');
let cors = require('cors');
let routes = require('./routes');
let PORT = 3000 || process.env.PORT;

app.use(logger('dev'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));
app.use('/api', routes);

require('./db-connection')(() => {
    app.listen(PORT, () => console.log(`Book Info Management App is running on port ${PORT}`));
});

module.exports = app; //testing