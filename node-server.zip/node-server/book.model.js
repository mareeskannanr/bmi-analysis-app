let mongoose = require('mongoose');
let Schema = mongoose.Schema;
var ValidationError = mongoose.Error.ValidationError;
var ValidatorError  = mongoose.Error.ValidatorError;

let bookSchema = new Schema({
    isbn: {
        unique: true,
        type: String,
        required: true,
        trim: true,
        sparse: true,
        validate: {
            validator: isbn => /^[0-9]{10}|[0-9]{13}$/.test(isbn),
            message: 'ISBN must have 10 or 13 digits'
        }
    },
    name: {
        type: String,
        required: true,
        trim: true,
        sparse: true
    },
    description: {
        type: String,
        trim: true,
        sparse: true
    },
    authors: {
        type: [{
            type: Schema.Types.String,
            trim: true,
            sparse: true
          }],
        validate: [
            {validator: array => array.length > 0,  msg: 'Atleast one author name is required'},
            {validator: array => array.length == new Set(array).size,  msg: "Author's name must be unique"}
        ]
    },
    yearOfPublish: {
        type: Number,
        min: [1700, 'Year Of Publish value must between 1700 and 2040'],
        maximum: [2040, 'Year Of Publish value must between 1700 and 2040'],
        exclusiveMaximum: false
    },
    price: {
        type: Number,
        min: [1, 'Price must be greater than zero.']
    }
});

module.exports = mongoose.model('Book', bookSchema);