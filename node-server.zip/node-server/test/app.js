process.env.NODE_ENV = 'test';

const Book = require('../book.model');
const chai = require('chai');
const chaiHttp = require('chai-http');
const server = require('../app');
const assert = require('assert');
const should = chai.should();

chai.use(chaiHttp);

describe(`Get All Books Test`, () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    describe('Get All Book Info ', () => {
        it('This REST API call should return all the books', done => {
            chai.request(server).get('/api/books').end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('array');
                res.body.should.be.length(0);
                done();
            });
        });
    });
});

describe(`Save a Book Test`, () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    describe('Posting Book Info', () => {
        it('Should Return Validation Error', done => {
            let book = {
                "isbn": "1",
                "name": "",
                "description": "",
                "authors": ["Callan", "Elena"],
                "yearOfPublish": 0
            };

            chai.request(server).post('/api/books').send(book).end((err, res) => {
                res.should.have.status(422);
                res.body.errors.should.be.an('array').that.is.not.empty;
                done();
            });
        });

        it('Should Save Book Information', done => {
            let book = {
                "isbn": "1234567890",
                "name": "Wonderful World!",
                "description": "A Book Regarding the Wonder of the World",
                "authors": ["Harry", "Watson"],
                "yearOfPublish": 2018
            };

            chai.request(server).post('/api/books').send(book).end((err, res) => {
                res.should.have.status(201);
                res.body.should.be.a('object');
                assert.equal(res.body.message, 'Book Information Added Successfully!');

                chai.request(server).get('/api/books').end((error, result) => {
                    result.should.have.status(200);
                    result.body.should.be.a('array');
                    result.body.should.be.length(1);
                    done();
                });
            });

        });
    });
});

describe('Get Book Information By Id', () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    it('Should Get Book Information By Id', done => {
        let book = new Book({
            "isbn": "1234567890",
            "name": "The Lord Of Rings",
            "description": "A Commercial and Adventrous Book For Reading",
            "authors": ["J.R.R.Tolkien"],
            "yearOfPublish": 1954
        });

        book.save((err, bookInfo) => {
            chai.request(server).get('/api/book/' + book.id).end((error, res) => {
                res.should.have.status(200);
                assert.equal(book.isbn, res.body.isbn);
                assert.equal(book.yearOfPublish, res.body.yearOfPublish);
                assert.equal(book.name, res.body.name);
                done();
            });
        });

    });
});

describe('Update Book Details', () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    it('Should Update Book Information', done => {
        let book = new Book({
            "isbn": "1234567890",
            "name": "The Lord Of Rings",
            "description": "A Commercial and Adventrous Book For Reading",
            "authors": ["J.R.R.Tolkien"],
            "yearOfPublish": 1954
        });

        book.save((err, bookInfo) => {
            let updateBook = {
                "isbn": "01234567891",
                "name": "The Lord Of Rings-II",
                "description": "A Commercial and Adventrous Book For Reading",
                "authors": ["J.R.R.Tolkien"],
                "yearOfPublish": 2007,
                "id": book.id
            };

            chai.request(server).put('/api/book/' + book.id).send(updateBook).end((error, res) => {
                res.should.have.status(200);
                assert.notEqual(book.isbn, res.body.isbn);
                assert.notEqual(book.yearOfPublish, res.body.yearOfPublish);
                assert.notEqual(book.name, res.body.name);
                assert.equal(res.body.message, 'Book Information Updated Successfully!');
                done();
            });
        });
    });
    
});

describe('Delete Book Information By Id', () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    it('Should Remove Book Information', done => {
        let book = new Book({
            "isbn": "1234567890",
            "name": "The Lord Of Rings",
            "description": "A Commercial and Adventrous Book For Reading",
            "authors": ["J.R.R.Tolkien"],
            "yearOfPublish": 1954
        });

        book.save((err, bookInfo) => {
            chai.request(server).delete('/api/book/' + book.id).end((error, res) => {
                res.should.have.status(204);
                done();
            });
        });
    });
    
});

describe('Delete All Book Informations', () => {
    beforeEach(done => {
        Book.remove({}, () => done());
    });

    it('Should Remove Book Information', done => {
        let book = new Book({
            "isbn": "1234567890",
            "name": "The Lord Of Rings",
            "description": "A Commercial and Adventrous Book For Reading",
            "authors": ["J.R.R.Tolkien"],
            "yearOfPublish": 1954
        });

        book.save((err, bookInfo) => {
            chai.request(server).delete('/api/books').end((error, res) => {
                res.should.have.status(204);
                done();
                process.exit();
            });
        });
    });
    
});