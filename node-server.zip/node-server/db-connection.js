const mongoose = require('mongoose');
const config = require('./config');

module.exports = function(connectionCB) {
    let URL = process.env.MONGODB_URI || config.DB_URL;
    mongoose.connect(URL);
    mongoose.Promise = Promise; 
    let DB = mongoose.connection;
    DB.on('error', console.error.bind(console, 'MongoDB connection error: '));
    DB.once('open', () => {
        console.log("MongoDB connection opened successfully!");
        connectionCB();
    });
};