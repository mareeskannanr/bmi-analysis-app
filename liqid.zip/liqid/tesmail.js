const mailer = require('sendmail')();

mailer({
    from: 'no-reply@liqid.com',
    to: 'mareeskannan.r@tcs.com',
    subject: 'Stock Information Search Response',
    html: 'Stock Information Search Response',
  }, (err, reply) => {
    console.log(err && err.stack);
    console.dir(reply);
  });